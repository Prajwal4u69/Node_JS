var http = require('http');
var url = require('url');
var fs = require('fs');

http.createServer(function (req, res) {


  var filename = url.parse(req.url).pathname;
  fs.readFile(filename, function(err, data) {

    switch (filename) {
        case '/h':
        res.writeHead(200, {'Content-Type': 'text/html'});
        fs.readFile('./index.html', null, function(error, data) {
        if (error) {
            res.writeHead(404);
            res.write('File not found!');
        } else {
            res.write(data);
        }
        res.end();
    });
        break;
        case '/':
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.write("Bhupiya");
         return res.end();

        default:
        res.writeHead(404, {'Content-Type': 'text/html'});
        return res.end("404 Not Found");
          }
  });
}).listen(8080);
